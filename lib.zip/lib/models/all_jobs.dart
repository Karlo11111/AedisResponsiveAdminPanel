List<String> jobRoles = [
  'Cleaner',
  'Pool Boy',
  'Concierge',
  'Bellhop',
];
